# datamagus
[![PyPI](https://img.shields.io/badge/PyPI-0.0.1-yellow)](https://pypi.org/project/datamagus/)</br>
Packages and API interface for basic data analysis processing, graphing and modeling, and practical use.


## Installation
```
pip install datamagus
```