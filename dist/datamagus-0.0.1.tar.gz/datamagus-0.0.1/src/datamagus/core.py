'''core code for data analysis'''
from pandas import DataFrame

class DataMagus(DataFrame):
    pass




