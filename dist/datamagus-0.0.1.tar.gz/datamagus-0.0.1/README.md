# datamagus
Packages and API interface for basic data analysis processing, graphing and modeling, and practical use.
